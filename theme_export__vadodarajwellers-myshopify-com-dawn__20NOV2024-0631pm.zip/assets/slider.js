document.addEventListener("DOMContentLoaded", function() {
    let currentIndex = 0;
    const items = document.querySelectorAll('.simple-slider__item');
    const totalItems = items.length;
    const itemsPerSlide = 6; // Set the number of items to display per slide
    const container = document.querySelector('.simple-slider__container');

    // Function to update the slider position
    function updateSlider() {
        const itemWidth = items[0].clientWidth; // Width of a single item
        // Move the container based on currentIndex
        container.style.transform = `translateX(-${currentIndex * itemWidth}px)`;
    }

    // Event listener for next button
    document.querySelector('.simple-slider__next').addEventListener('click', () => {
        currentIndex++;
        if (currentIndex > totalItems - itemsPerSlide) {
            currentIndex = 0; // Reset to the first item
        }
        updateSlider();
    });

    // Event listener for previous button
    document.querySelector('.simple-slider__prev').addEventListener('click', () => {
        currentIndex--;
        if (currentIndex < 0) {
            currentIndex = totalItems - itemsPerSlide; // Go to the last items
        }
        updateSlider();
    });

    // Initial update
    updateSlider();
});
