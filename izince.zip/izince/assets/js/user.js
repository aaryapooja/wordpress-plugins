/* Custom Scripts */

$(document).ready(function () {
  /*------------------------------------------------------*/
  // Carousel
  /*------------------------------------------------------*/

  if ($.fn.slick) {
    // Checks if Slick is loaded
    $(".tradingSoln-slider").slick({
      dots: false,
      arrows: true,
      infinite: true,
      speed: 500,
    });

    $(".cardSlider").slick({
      dots: true,
      arrows: false,
      infinite: true,
      speed: 500,
    });
  } else {
    console.error("Slick slider is not loaded.");
  }

  /*------------------------------------------------------*/
  // Password field toggle eye
  /*------------------------------------------------------*/

  $(".toggle-password").click(function () {
    $(this).find("#eye").toggleClass("d-none");
    $(this).find("#eye-off").toggleClass("d-none");
    var input = $($(this).attr("toggle"));
    if (input.attr("type") == "password") {
      input.attr("type", "text");
    } else {
      input.attr("type", "password");
    }
  });

  /*------------------------------------------------------*/
  // Clear Input Value
  /*------------------------------------------------------*/
  document.querySelectorAll(".clear").forEach((clearIcon) => {
    clearIcon.addEventListener("click", function () {
      const inputField = this.closest(".input-group").querySelector("input");
      if (inputField) {
        inputField.value = ""; // Clear the input value
      }
    });
  });

  /*------------------------------------------------------*/
  // Toggle referral code input
  /*------------------------------------------------------*/
  function toggleReferralInput() {
    const referralInput = document.getElementById("referralCodeInput");
    const checkbox = document.getElementById("referralCode");
    referralInput.style.display = checkbox.checked ? "block" : "none";
  }

  // Call the function initially to set the correct visibility based on initial checkbox state
  toggleReferralInput();

  function toggleReferralMobileInput() {
    const referralInput = document.getElementById("referralCodeMobileInput");
    const checkbox = document.getElementById("referralCodeMobile");
    referralInput.style.display = checkbox.checked ? "block" : "none";
  }
  toggleReferralMobileInput();

  /*------------------------------------------------------*/
  // Sidenav link active status
  /*------------------------------------------------------*/
  var currentUrl = window.location.href;
  $(".sidenav .nav-link").each(function () {
    var link = $(this).attr("href");
    if (currentUrl.includes(link)) {
      $(".sidenav .nav-link").removeClass("active");
      $(this).addClass("active");
    }
  });

  /*------------------------------------------------------*/
  // Datepicker, Timepicker & Daterangepicker
  /*------------------------------------------------------*/

  // $("#subscriptionStartDate").datepicker({
  //   format: "mm/dd/yyyy",
  //   autoclose: true,
  //   todayHighlight: true,
  //   todayBtn: "linked",
  //   clearBtn: true,
  // });

  // $(".input-group-text").on("click", function () {
  //   $("#subscriptionStartDate").datepicker("show");
  // });

  // $(document).ready(function () {
  //   let firstOpen = true;

  //   $("#timePicker")
  //     .datetimepicker({
  //       useCurrent: false,
  //       format: "hh:mm:ss A",
  //       icons: {
  //         up: "fas fa-chevron-up",
  //         down: "fas fa-chevron-down",
  //       },
  //     })
  //     .on("dp.show", function () {
  //       let time;
  //       if (firstOpen) {
  //         time = moment().startOf("day");
  //         firstOpen = false;
  //       } else {
  //         time = moment("01:00 PM", "hh:mm A");
  //       }

  //       $(this).data("DateTimePicker").date(time);
  //     });

  //   // Open datetimepicker when the addon is clicked
  //   $("#timePickerAddon").on("click", function () {
  //     $("#timePicker").focus();
  //   });

  //   // $("#timePicker").data("DateTimePicker").show();
  // });

  // $(function () {
  //   $('input[name="daterange"]').daterangepicker({
  //     opens: "left",
  //   });

  //   $(".input-group-text").on("click", function () {
  //     $(this).closest(".input-group").find("input[name='daterange']").focus();
  //   });
  // });

  /*------------------------------------------------------*/
  // Select All Checkbox
  /*------------------------------------------------------*/
  function updateSelectAll(selectAll, checkboxes) {
    var allChecked = Array.from(checkboxes).every(
      (checkbox) => checkbox.checked
    );
    var someChecked = Array.from(checkboxes).some(
      (checkbox) => checkbox.checked
    );

    selectAll.checked = allChecked;
    if (!allChecked && someChecked) {
      selectAll.indeterminate = true;
      selectAll.classList.add("indeterminate");
    } else {
      selectAll.indeterminate = false;
      selectAll.classList.remove("indeterminate");
    }
  }

  /*------------------------------------------------------*/
  // Login step form
  /*------------------------------------------------------*/

  var current_fs, next_fs, previous_fs; //fieldsets
  var opacity;
  var current = 1;
  var steps = $("fieldset").length;

  setProgressBar(current);

  $(".next").click(function () {
    current_fs = $(this).parent();
    next_fs = $(this).parent().next();

    //Add Class Active
    $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");

    //show the next fieldset
    next_fs.show();
    //hide the current fieldset with style
    current_fs.animate(
      { opacity: 0 },
      {
        step: function (now) {
          // for making fielset appear animation
          opacity = 1 - now;

          current_fs.css({
            display: "none",
            position: "relative",
          });
          next_fs.css({ opacity: opacity });
        },
        duration: 500,
      }
    );
    setProgressBar(++current);
  });

  $(".previous").click(function () {
    current_fs = $(this).parent();
    previous_fs = $(this).parent().prev();

    //Remove class active
    $("#progressbar li")
      .eq($("fieldset").index(current_fs))
      .removeClass("active");

    //show the previous fieldset
    previous_fs.show();

    //hide the current fieldset with style
    current_fs.animate(
      { opacity: 0 },
      {
        step: function (now) {
          // for making fielset appear animation
          opacity = 1 - now;

          current_fs.css({
            display: "none",
            position: "relative",
          });
          previous_fs.css({ opacity: opacity });
        },
        duration: 500,
      }
    );
    setProgressBar(--current);
  });

  function setProgressBar(curStep) {
    var percent = parseFloat(100 / steps) * curStep;
    percent = percent.toFixed();
    $(".progress-bar").css("width", percent + "%");
  }

  $(".submit").click(function () {
    return false;
  });

  /*------------------------------------------------------*/
  // Country code with flag
  /*------------------------------------------------------*/

  const input = document.querySelector("#phone");
  const iti = window.intlTelInput(input, {
    // separateDialCode: true,
    initialCountry: "us",
    utilsScript:
      "https://cdn.jsdelivr.net/npm/intl-tel-input@24.4.0/build/js/utils.js",
  });

  // store the instance variable so we can access it in the console e.g. window.iti.getNumber()
  window.iti = iti;
});
