<?php  
/**  
 * Plugin Name: 3D Swipe Slider  
 * Description: A simple shortcode for displaying a 3D swipe slider.  
 * Version: 1.0  
 * Author: Your Name  
 */  

// Enqueue styles and scripts  
function swipe_slider_enqueue_scripts() {  
    wp_enqueue_style('materialize-css', plugins_url('css/materialize.min.css', __FILE__));  
    wp_enqueue_style('swipe-slider-style', plugins_url('style.css', __FILE__)); // Enqueue your custom style.css  
    wp_enqueue_script('jquery'); // Load jQuery  
    wp_enqueue_script('materialize-js', 'https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js', array('jquery'), null, true);  
}  
add_action('wp_enqueue_scripts', 'swipe_slider_enqueue_scripts');  




function swipe_slider_shortcode() {  
    ob_start(); // Start output buffering  
    ?>  
    <div class="carousel">  
        <div class="carousel-item">  
            <img src="<?php echo plugins_url('images/img1.png', __FILE__); ?>" />  
        </div>  
        <div class="carousel-item">  
            <img src="<?php echo plugins_url('images/img2.png', __FILE__); ?>" />  
        </div>  
        <div class="carousel-item">  
            <img src="<?php echo plugins_url('images/img3.png', __FILE__); ?>" />  
        </div>  
        <img src="<?php echo plugins_url('images/mobile2.png', __FILE__); ?>" class="mobile"/>   
    </div>  
    <div class="indicator-wrapper">
        <span class="indicator-dot" data-slide="0"></span>
        <span class="indicator-dot" data-slide="1"></span>
        <span class="indicator-dot" data-slide="2"></span>
    </div>
    <script type="text/javascript">  
        document.addEventListener('DOMContentLoaded', function() {  
            var elems = document.querySelectorAll('.carousel');  
            var instances = M.Carousel.init(elems, {});  
        });  

        // jQuery version  
        jQuery(document).ready(function($) {  
            $('.carousel').carousel();  

            // Update active indicator
            $('.indicator-dot').on('click', function() {
                var slideIndex = $(this).data('slide');
                $('.carousel').carousel('set', slideIndex);
                updateIndicators(slideIndex);
            });

            function updateIndicators(activeIndex) {
                $('.indicator-dot').removeClass('active');
                $('.indicator-dot[data-slide="' + activeIndex + '"]').addClass('active');
            }

            // Auto-update indicators on slide
            $('.carousel').on('carouselNext carouselPrev', function(e, instance) {
                updateIndicators(instance.center);
            });
        });
    </script>  
    <?php  
    return ob_get_clean(); // Return the buffered content  
}  
add_shortcode('3d_swipe_slider', 'swipe_slider_shortcode');
